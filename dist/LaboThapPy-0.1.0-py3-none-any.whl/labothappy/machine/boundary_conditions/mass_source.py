class MassSource:
    def __init__(self):
        self.connectors = {}