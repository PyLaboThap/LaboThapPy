class WorkSource:
    def __init__(self):
        self.connectors = {}