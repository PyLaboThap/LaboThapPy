class HeatSink:
    def __init__(self):
        self.connectors = {}