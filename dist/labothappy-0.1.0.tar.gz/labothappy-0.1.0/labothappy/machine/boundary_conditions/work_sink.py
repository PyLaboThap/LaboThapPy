class WorkSink:
    def __init__(self):
        self.connectors = {}