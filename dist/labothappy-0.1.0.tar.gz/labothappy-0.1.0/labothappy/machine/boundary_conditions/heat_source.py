class HeatSource:
    def __init__(self):
        self.connectors = {}